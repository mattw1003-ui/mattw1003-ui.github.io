# Provenance and limitations

The design was informed by a portfolio review, selected sanitized Hub source and icon, user-reported needs and working integrations, and reviewed source notes. Original app archives were not directly inspected for this design. Selected source snapshots and historical archive findings do not establish current production configuration, complete source coverage or deployed feature parity.

The SML icon in prototype/assets/sml-icon.png is retained unmodified from the selected sanitized Hub source. Other screens, plans, observations, recipients, examples, memories, teams and sample usage are synthetic. The displayed company/domain context is a proposed identity label, not a verified account or a grant of access. Example email recipients use example.invalid. No real client evidence or reusable professional signature artwork is included.

Working connections and configured providers were reported by the user; current grants, effective models, access groups, app identity, backend ownership and production behavior were not independently verified. Verify capabilities through approved read-only inspection before implementation. Never copy secrets or assume a session transfers between bundles or contexts.

The original design record reports 129 browser checks, selected contrast checks and synthetic screenshot review. Those are historical design results, not a new test run of this repackaging. This release preparation checked package integrity, content and PDF rendering without executing contained app scripts. It did not run native Apple, live backend, provider, audio, account, billing, security, backup/restore or professional issuance tests.

Local browser storage and scripted interactions demonstrate proposed behavior only. Work/Personal isolation needs enforcement below the UI. Model use, external effects, specialist execution, consent, budgets, cancellation and receipts need verified backend implementation. Professional review, engineering acceptance, signing and commercial approval remain distinct human authority gates.

Current Hub versus PlanPilot ownership of operational domains remains unresolved. Use one approved writer per domain, preserve exact source/job identity and rehearse restore/rollback before any migration. Obsidian remains the proposed primary knowledge source; memory and graph are traceable projections.

Documentation links in docs/INTEGRATION-NOTES.md are retained from the dated design as implementation references. Recheck current documentation, API availability, account eligibility, retention, cost and policy before implementing any connected feature. No provider documentation proves this account's access.
