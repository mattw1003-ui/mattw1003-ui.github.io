# Shared contract proposal · v0.1

These are proposed mobile/domain contracts, not claims that endpoints already exist. Adapt to verified Hub and PlanPilot owners after Gate O. JSON uses lower_snake_case fields; IDs are UUIDs unless an explicit source system uses an opaque identifier. Never regenerate IDs from project names.

## Common envelope

Every mutable record: `schema_version`, `id`, `tenant_id`, `context_id`, `project_id` (nullable only for genuinely unassigned/context-wide records), `revision`, `created_at`, `updated_at`, `created_by`, `source_refs[]`. Timestamp values are RFC 3339 with zone; visit local date/time zone is also retained. A source reference stores system, exact record ID, source version, captured-at and authorized locator. Server authorization derives tenant/context from the authenticated session and compares payload scope; trusting a supplied tenant is prohibited.

Every mutation: `operation_id`, `context_id`, `record_id`, `base_revision`, `payload`, `payload_sha256`, `client_captured_at`. The idempotency uniqueness key is `(tenant_id, context_id, operation_id)`. Repeating the same key and hash returns the stored result; different hash returns conflict. Commit event and state together. Acknowledgment contains server sequence, accepted revision, operation ID and result hash. A lost acknowledgment does not warrant a new operation ID.

## Records and invariants

| Record | Required domain fields | Invariant |
|---|---|---|
| Project | `job_id_exact`, `display_name`, `source_identity[]`, `aliases[]`, `parent_project_id?`, `authority_source`, `access_revision` | Exact job string/suffix preserved. Parent relationship never means identity equality |
| IdentityMap | `source_system`, `source_tenant`, `source_record_id`, `app_uuid`, `raw_job_id`, `status`, `approved_by?`, `mapping_evidence[]` | Unique source tuple. Conflicting mappings quarantined. Names not keys |
| Visit | `project_id`, `job_id_snapshot`, `scope`, `inspection_type`, `local_date`, `time_zone`, `plan_pack_id`, `state` | Project binding immutable after capture except audited reassignment with lineage |
| DocumentVersion | `document_id`, `original_blob_id`, `sha256`, `sheet_id`, `revision_label`, `approval_evidence[]`, `supersedes[]` | Upload time is not controlling precedence |
| PlanControlDecision | `project_id`, `sheet_id`, `selected_version_id`, `replaces_decision_id?`, `basis`, `actor`, `decided_at` | Server verifies authority and frozen source. Ambiguity stays pending |
| Evidence | `visit_id`, `kind`, `original_blob_id`, `sha256`, `media_type`, `byte_count`, `captured_at`, `actor`, `device`, `location?`, `parent_evidence_id?` | Original bytes immutable; derivation stores algorithm/version/parent hash |
| Citation | `evidence_id`, `document_version_id`, `document_sha256`, `page_index`, `page_label`, `sheet_id?`, `quote`, `quote_sha256`, `text_span?`, `region?`, `quote_status`, `claim_support_status`, `reviewer?` | Exact quote verification and claim support are separate. Every relied-on citation must pass |
| SegmentCoverage | `source_id`, `segment_id`, `start_ms/end_ms` or `text_span`, `finding_ids[]`, `status`, `exclusion_reason?`, `review_revision` | Some findings from a segment do not imply complete coverage; statuses unreviewed/partial/reviewed/excluded |
| Finding | `visit_id`, `kind`, `observation`, `disposition`, `citation_ids[]`, `evidence_ids[]`, `coverage_ids[]`, `limitations[]` | AI suggestions cannot set professional acceptance; edits invalidate dependent review |
| ReportRevision | `report_id`, `version`, `visit_id`, `content_sha256`, `evidence_manifest_sha256`, `plan_control_decision_ids[]`, `status`, `required_evidence[]`, `template_version` | Submitted version frozen. All required content available before submission |
| EngineeringDecision | `report_revision_id`, `content_sha256`, `manifest_sha256`, `decision`, `reason`, `actor_id`, `authority_policy_version`, `decided_at` | Distinct type/capability from ActionConsent. Cannot be reused for changed content |
| IssuedArtifact | `report_revision_id`, `blob_id`, `sha256`, `byte_count`, `manifest_id`, `review_decision_id`, `signer_id`, `signer_authorization_version`, `render_settings_hash`, `issued_at`, `supersedes_id?` | Exact bytes saved once. New settings never alter historical artifacts |
| AttentionItem | `source_type`, `source_id`, `source_revision`, `domain`, `priority`, `reason`, `due_at?`, `assignee`, `state`, `next_route` | Projection into one queue; domain record owns validity. Dismissal cannot change report/action state |
| Conversation | `context_id`, `project_id?`, `chief_session_id`, `message_ids[]`, `context_manifest` | Existing Chief session; personal/work memory isolated |
| RunRequest | `chief_run_id?`, `objective`, `scope_manifest`, `tool_allowlist`, `caps`, `consent_id?`, `state`, `configuration_receipt?`, `usage_receipt?` | Run consent is not engineering approval or blanket external-action consent |
| BudgetReservation | `run_id`, `currency`, `reserved_minor`, `settled_minor?`, `status`, `provider_request_id?` | Durable atomic cap checks across workers; unknown amount null; hold until reconciled |
| ActionProposal | `kind`, `account_id`, `recipients[]`, `payload`, `attachment_hashes[]`, `payload_sha256`, `source_refs[]`, `state` | Exact account and payload shown; no recipient inferred from display name alone |
| ActionConsent | `proposal_id`, `payload_sha256`, `actor`, `scope`, `expires_at`, `decision`, `authorization_policy_version` | Server rechecks scope, revision, expiry and capability immediately before execution |
| ExternalReceipt | `proposal_id`, `operation_id`, `provider`, `provider_action_id`, `payload_sha256`, `status`, `observed_at`, `verification_method` | Only verified effect establishes completion. Client clock/schedule cannot produce it |
| AuditEvent | `sequence`, `actor`, `context`, `entity_id`, `entity_revision`, `event_type`, `before_hash?`, `after_hash?`, `receipt_id?`, `server_at` | Append-only authority events; correlation links across one timeline |
| RecoveryManifest | `archive_id`, `schema_version`, `context_id`, `files[{path,bytes,sha256}]`, `record_counts`, `encryption_metadata`, `verified_at?`, `restore_receipt?` | No missing required artifact silently accepted; do not store key material in manifest |

## State machines

**Report:** draft → submitted(frozen) → changes_requested or professionally_reviewed → issued. Edits create a new draft revision; they invalidate prior review for that new content. Issue requires designated signer, complete evidence, valid authority and matching hashes. There is no draft → issued shortcut. A nonconformance may remain documented in an issued report under policy, but cannot be relabeled conforming merely to pass a gate. Withdrawal/supersession links preserve the historical artifact.

**External action:** draft → awaiting_consent → authorized → executing → confirmed / failed / outcome_unknown. An expired/changed payload returns to awaiting_consent. From outcome_unknown only reconciliation can determine confirmed, definitely_not_executed or still_unknown; retry is allowed only when definitely_not_executed or the provider guarantees same-key idempotency. A device reminder requires a durable local transaction/operation ID and retained external ID, with reconciliation across interruptions.

**Run:** proposed → awaiting_consent → queued → running → completed / partial / failed / canceled / outcome_unknown. A scheduled run has a separate schedule record; “due” is not “ran.” Canceling a run cannot cancel an already completed external side effect. Completed run means its bounded task completed, not all project obligations resolved.

**Sync:** local_durable → pending → uploading → acknowledged; conflict/failed requires visible recovery. Acknowledged is independent of backed_up and restored_verified.

## API surface to implement behind existing owners

| Operation | Semantics |
|---|---|
| `GET /mobile/v1/context` | Authenticated capabilities, scope revision, server time, offline policy and effective backend versions |
| `GET /mobile/v1/projects?cursor=` | One authorized registry; exact IDs, source mappings and freshness |
| `GET /mobile/v1/attention?domain=&cursor=` | One queue; stable server ordering and counts from same predicate |
| `GET /mobile/v1/changes?after=` | Scoped monotonic change cursor, tombstones and revocations; cursor reset triggers safe resync |
| `POST /mobile/v1/mutations` | Idempotent domain command envelopes; per-command result; base-revision CAS |
| `POST /mobile/v1/uploads` | Resumable content upload scoped to project; finalize validates hash and byte count |
| `GET /mobile/v1/operations/{operation_id}` | Reconcile lost acknowledgment; never guess completion |
| `POST /mobile/v1/chief/runs` | Versioned adapter to existing Chief; scope/capability/budget checks |
| `POST /mobile/v1/actions/{id}/consents` | Exact payload-hash consent; no execution implied |
| `GET /mobile/v1/actions/{id}/receipts` | Verified external state and reconciliation evidence |
| `POST /mobile/v1/reports/{id}/reviews` | Frozen revision, professional capability and hash checks |
| `POST /mobile/v1/reports/{id}/issues` | Separate signer capability, immutable artifact commit and audit |

For 409 retain local draft and server version; show a conflict. For 403 stop scoped reads/writes and apply revocation policy. For 429 retain operation ID and reservation. For network timeout mark unknown until operation lookup. Credentials remain in platform secure storage; transport requires HTTPS validation and redirect refusal, with independent implementation verification. No app-embedded provider keys.

## Optional handoff extensions

`MeasurementEvidence`: value, SI unit, method/version, uncertainty model/version, latest calibration outcome/time/validity, raw artifact hashes, per-export-format transform matrix and whether applied. Conflicting scale references or latest failed calibration block “valid” status. A geometric envelope is not automatically floor area.

`MaterialEvidence`: lot/heat/sample identifiers, original attachments/hashes, field-to-page links, OCR/raw text, field verification actor/status and amendment chain. Original OCR is not overwritten. Import is deduplicated by source app record ID plus version/hash, never project name. Local unsigned checksums are integrity evidence, not authenticated professional attestation.
