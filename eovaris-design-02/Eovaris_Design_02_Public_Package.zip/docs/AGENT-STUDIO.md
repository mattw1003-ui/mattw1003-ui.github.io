# Agent Studio and bounded specialist teams

Design addition approved by Matthew, 25 October 2026. Internal AI delegation only; “hire” does not mean recruiting humans, buying services or granting account access. No real subagent, paid avatar generation or provider call was made.

## Matthew’s experience

From Collaborate, open Agent Studio. Name the Work lead and Personal lead independently; choose an abstract avatar/monogram, select a permitted local image, or explore a separately approved generated-avatar flow. The Work/Personal context and verified identity remain visible regardless of the chosen name. A familiar name or avatar cannot disguise which account will act.

Profile fields: display name, avatar/source, role description, tone, permitted provider/model route, workspace, memory scope, tool subset, autonomy, delegation concurrency/depth/time and shared task budget. Role/persona text is preference data; security policy is enforced outside it. A model/provider roster must come from verified approved configuration, not arbitrary free text. Preserve existing server-side provider routes and credential references.

The prototype implements name/role/tone selection, abstract avatar choices, local PNG/JPEG/WebP selection, context-scoped profile persistence and an inert generated-avatar consent preview. Its sample preview selects a prebuilt symbol; it does not generate an image. A production generated avatar requires a disclosed provider, verified price estimate, budget reservation, selected image prompt/input, retention/rights policy, explicit consent and completion/usage receipt. A declined or unknown result cannot trigger repeated paid generation. Recorded-person voice cloning is unrelated and separately gated.

## Delegation journey

1. Matthew or the authorized lead proposes a specialist for a defined deliverable inside a parent task. Example: “Evidence Scout — check this visit’s missing evidence.”
2. Review purpose, source selection, tool subset, output format, deadline, maximum depth, concurrency and budget reservation. Parent scope is a ceiling, not an automatic grant of every permission.
3. The child receives only selected authorized source IDs/excerpts and memory needed for its task. No raw provider credentials, whole-context chat history or cross-workspace memory is handed down. Execution uses scoped brokered capabilities.
4. Team view shows parent/child relationship, purpose, status, deliverable, provenance, budget reservation and actual reported usage or unreported. A progress animation or child “done” is not completion proof.
5. Parent reviews the result and its cited source coverage, resolves conflicts and incorporates an accepted draft into the parent artifact. Professional and external-action approvals still apply afterward.
6. Specialists are ephemeral by default. An explicit Save reusable profile retains the role, output contract and permitted tool template—not old credentials, client evidence or prior grants. Reuse reauthorizes against the new task/context.

## Defaults and limits

Proposed starting policy: at most two concurrent specialists, depth one with no recursive child spawning, and a shared parent time/step/spend ceiling. Child ceilings are smaller slices of that total, not additional full budgets. The synthetic prototype demonstrates one/two concurrency limits, a $0.75 child reservation inside a selected $1/$2/$5 task cap and a displayed 60-second child cap inside a 2-minute parent cap. These are demo policy examples, not quoted provider prices. Time enforcement, leases and real budget settlement are backend acceptance gates.

“Actual usage” is null/unreported until a verified provider receipt exists. The prototype labels its illustrative $0.12 result usage as simulated and separately states that no provider was called. Aggregate parent accounting must avoid counting a delegated provider request twice.

Parent cancellation sets a durable fence, propagates to active children and prevents unstarted effects. Running/uncertain effects need cancellation acknowledgment and reconciliation. Completed result and external receipts remain in history. A child cannot reopen a canceled parent or launch a new attempt behind the user’s back.

Disagreement creates a review item with the conflicting claims and sources. The parent can seek clarification or reject a result; majority vote is not engineering authority. Accepting a specialist draft is not a signed professional determination, invoice approval or external-action consent.

## Contracts

`AgentProfile`: profile_id, context_id, display_name, avatar_reference/hash/provenance, role, tone, permitted_provider/model_policy_id, memory_policy_id, tool_policy_subset, default_autonomy, delegation_policy and budget_policy. A saved profile records version/actor; no secret fields.

`Delegation`: parent_task/attempt_id, child_task/attempt_id, context_id, profile_snapshot, purpose, selected_source_manifest, selected_memory_manifest, capability_subset, output_contract, maximum_depth, remaining_steps/time, reservation_id, cancellation_fence_version and status.

`SpecialistResult`: child_id, output_artifact_id/revision, source_refs, coverage/limitations, completion_receipt, usage_receipt or null, conflict_state and parent_review_event. Result content is untrusted task data until reviewed; it cannot alter system policy.

`AvatarGenerationProposal`: context, input/prompt hashes, provider/model when verified, quote/ceiling, consent, operation_id, reservation and result/usage receipt. Profile changes are committed only after a verified permitted result; retries reconcile the original operation.

## Prototype versus production

Implemented as synthetic browser interactions: custom profile and avatars; local image selection; sample-generation consent; ephemeral specialist delegation; concurrency/shared-budget checks; result/conflict review; save/reuse profile; parent-cancel propagation; context-separated teams. No real child tasks, generation or access grants. Backend capability enforcement, actual timeouts, cancellation races, secure file handling, provider billing and native persistence remain untested.
