# Reuse and migration boundaries

Evolve Eovaris with the strongest PlanPilot and FieldScribe workflows while preserving compatible working access. This is a design decision, not an authorization to migrate data, change identity or create new grants.

## Evidence and identity

The user reported working provider links and Microsoft/Quo connections. Reviewed archive notes and selected sanitized source informed the proposal, but original app archives were not directly inspected and current production parity is unknown. A current build/backend and capability inventory must precede implementation. Do not infer live behavior from an older archive or a UI label.

Inventory the current bundle identity, signing team, App ID prefix, access groups, credential-reference names, backend endpoints, source IDs and supported provider routes through approved mechanisms. Preserve compatible session references and server ownership of provider secrets. No exact live credential configuration is supplied in this package. A session valid in one bundle, access group or context is not automatically transferable.

Authentication, connector permissions and consent for a particular effect are separate. Microsoft sign-in does not establish Outlook mail/calendar authorization; an SMS authentication hook does not establish unrestricted business messaging or calling. Record capabilities as reported, verified, unsupported, requiring separate approval or unavailable. Company access stays in Work; a personal identity never inherits those grants.

## Backend and operational ownership

The existing Ops Hub Chief remains the proposed work execution owner. Reuse compatible versioned adapters instead of adding a competing execution authority. Reconcile the current Hub and PlanPilot writer for every operational domain before migration. Until approved, use read-only adapters and synthetic fixtures.

Use additive versioned migrations, exact job/source mappings and recorded before/after schemas. Preserve job suffixes and distinct same-name records. Rehearse encrypted backup, clean-device restore and rollback against authorized test data. Feature flags and compatible routes must preserve the working app; two writers must never update the same record domain.

## Authority and cutover

This design does not authorize new OAuth grants, redirect registrations, key/token movement, signing or entitlement changes, credential provisioning, billing changes or persistent access expansion. Any necessary new scope needs its own precisely bounded approval. Reuse cannot promise zero reauthorization.

Before cutover, demonstrate compatible upgrade behavior without exposing secrets; unchanged permitted provider behavior; adapter membership and role checks; denial of cross-context retrieval, graph, cache, export and notification access; exact identity/artifact/receipt round-trips; and rollback that never replays an external effect. Reconcile unknown outcomes before retry.

An optional research adapter remains subordinate to the same source scope, budget and consent controls. Preserve existing reasoning routes unless a change is approved. Research must retain citations, retrieval time, reviewed claims and limitations. It cannot become authoritative project evidence, an engineering determination or an approval. Do not send client evidence or work memory to a new provider without explicit authority.

See ARCHITECTURE-OVERVIEW.md, ROADMAP.md and ../PROVENANCE-AND-LIMITATIONS.md for unresolved ownership and implementation gates.
