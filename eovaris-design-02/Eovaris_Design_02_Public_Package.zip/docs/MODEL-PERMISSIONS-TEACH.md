# Models, permission modes and Teach

Matthew-approved design extension, 25 October 2026. These controls belong to the app being designed. No current assistant permissions, accounts, model weights, provider routes or production rules were changed.

## Model choice is primary

Collaborate exposes the selected provider/model and permission mode above Conversation/Tasks/Memory/Team. Agent Studio holds the lead’s default; each task can override it. A model choice is not buried under voice preferences. Work and Personal have separate approved rosters and defaults. Saved specialist profiles can request only a permitted subset of the parent’s roster.

Show exact provider and model ID, capability compatibility (text/image/audio/tools and supported context), provider-supported reasoning/speed settings, expected cost or explicitly unquoted estimate, task/voice caps and actual reported model/usage. Reasoning labels must map to documented supported values; unavailable controls are disabled rather than invented. User-reported Sonnet 5.5 and GPT-6.1 Sol defaults remain user reports until current effective configuration and receipts are inspected. Do not fabricate an exact Claude model ID.

The prototype offers the documented `OpenAI / gpt-6.1-sol` as a design choice, labels account access unverified, and shows its text/image versus direct-audio incompatibility. Existing routes remain available as unverified references; Claude’s exact ID is pending. Reasoning/speed controls are disabled pending a verified roster. Expected cost is unquoted with an illustrative cap; actual model is unreported because no model is called.

**No silent fallback or escalation.** If the selected route is unavailable, incompatible, blocked by policy or over budget, preserve the artifact and ask for a new permitted choice. An optional Auto route exists only after explicit selection of its allowed exact models, capability rules and shared budget. Display why each route was chosen and its actual receipt. Auto cannot step outside its set, expand access or infer consent from a vague “best model” preference.

Changing an agent default affects new tasks, not an already pinned task. A running task change requires a durable checkpoint and an explicit boundary: earlier outputs retain their model provenance; only subsequent steps use the new selected route. Record task/attempt/step, old/new model policy, actor and checkpoint. In-flight provider calls may need completion/reconciliation before a new step begins; changing a menu cannot retroactively change them. Invalidate approval when affected action content changes. Voice media model and reasoning/task model are distinct selections.

`ModelPolicy`: context, version, default_provider/model_id, allowed_overrides, supported_parameters, capability_metadata_version, Auto_opt_in, allowed_Auto_models, route_budget and policy_owner. `ModelSelection`: task/attempt, requested_provider/model, reason/speed values or provider_default, requested_at, applies_after_checkpoint, scope and selection_actor. `ModelReceipt`: request/step ID, requested identity, returned identity when provided, effective settings if reported, usage/cost receipt or null, routing reason, output artifact revision and limitations. Provider-default/unknown remains unknown; never infer the actual model from a UI label.

## Three enforceable modes

| Mode | Permitted behavior | Execution boundary |
|---|---|---|
| Assistant | Read permitted sources; write drafts, notes and internal task artifacts within existing authority | No sending, scheduling, publishing, deletion or other external side effects. Internal writes do not sign reports or change controlled professional authority |
| Collaboration | Prepare the work, then execute an approved exact action or clearly bounded batch | Live approval binds account, targets, exact payload/attachments, versions, allowed operations/count, cost, expiry and policy revision. A changed target/payload needs renewed approval |
| Proactive | Initiate and complete tasks within explicitly enabled standing scope | Label **Full access to selected scope**. Named workspace/tools/action types/targets, conditions, cadence, effect counts, time/spend limits and expiry/review are mandatory. No global unlimited access |

Assistant is the recommended starting mode. Authentication and connector grants remain prerequisites in every mode. A mode cannot create a credential, invent an OAuth scope, borrow another workspace’s account or override an app/system policy. Read-only provider use can still incur cost and needs its budget controls.

High-impact, irreversible, credential/security and professional sign-off gates remain separate. In particular, Proactive does not confer engineering reviewer/signer authority, acceptance of design changes, unrestricted deletion, billing approval or access provisioning. A professional review state never derives from a conversation’s permission mode.

Matthew’s examples: Assistant prepares tomorrow’s visit packet and follow-up draft. Collaboration shows the exact contractor email and calendar proposal as a bounded batch for live review. Proactive may prepare packets and send a narrowly authorized readiness request for named jobs/recipients within a configured cap/expiry; a reply changing scope or design creates a review item. It does not resolve that professional issue automatically.

Mode or scope changes increment a server policy revision. A downgrade revokes queued authority and pending leases/consents that no longer qualify. Every worker, child and adapter rechecks the current policy and cancellation fence immediately before the next side effect. Read/draft work may continue if still permitted. Already transmitted or uncertain operations remain receipt/reconciliation items; mode changes never pretend to undo them. Scheduler initiation and notification routes obey the same context policy.

`PermissionPolicy`: context/principal, mode, revision, owner, permitted_read/write domains, allowed_tools/actions, excluded/high-impact gates, standing_grants, spend/time/effect limits and expiry. `StandingGrant`: exact scope/target predicates, account, permitted action fields, human-reviewed conditions, cap/count/cadence, expiry/review date, source consent and revocation state. `ActionConsent`: payload/hash/version/attachments, destinations, batch limits, policy version, approving actor and expiry. `ExecutionClaim`: operation, current policy revision, consent/grant, budget reservation, fence version and receipt state. Child permissions are intersected with parent authority at execution time; re-delegation cannot bypass them.

Prototype behavior: Assistant disables external action simulation; Collaboration requires the existing exact-action checkbox; Proactive requires an explicit narrow standing-scope checkbox and displays Full access to selected scope. Downgrades clear queued authorization and preserve already simulated receipts. The example standing grant binds one task/artifact revision, account, action and cap with a two-hour demo expiry. This is UI/state logic, not a production policy engine or a real access grant.

## Teach: reviewed application behavior

Teach is a visible workflow for preferences/instructions, approved examples, templates, correction feedback, source-backed memory and reusable skills. The agent can suggest a lesson after a correction, but shows it for review. A user can also open Teach from Collaborate or Agent Studio.

1. Identify the behavior and source. Choose the context, affected tasks and applicability. Separate communication style from source facts and professional authority.
2. Preview the proposed change: current rule versus proposed version, supporting examples/template, source/owner, intended effect, affected tasks and explicit no-permission-change statement.
3. Run representative regression examples against the proposed behavior, including the target improvement and counterexamples: a similar but different job, an unresolved condition, a disallowed action and the other workspace. Keep actual outputs, model receipt and evaluation/reviewer decisions. A passing style example does not prove engineering correctness.
4. Activate only the reviewed version in its scope. Preserve prior versions and source provenance; record which task used which rule/template/skill version.
5. Inspect learned rules, correct/forget them or roll back behavior as a new auditable revision. Forgetting excludes active retrieval and prevents silent re-creation under the memory policy. Required source evidence is governed separately.

Email, retrieved text and model outputs cannot grant tools or execution rights, even if they contain imperative instructions. A reusable skill that proposes a new tool requires a separate reviewed policy change. Permission policy is enforced outside persona and learned-rule content. Trainability does not mean every conversation updates model weights or automatically fine-tunes on SML/personal data. Any future fine-tuning proposal is a separate data/retention/consent/cost decision and is not part of this design’s authorized activity.

`LearnedRule`: context, ID/type, version/status, text/template/skill reference, source refs, source time, owner/reviewer, applicability, supersession, allowed content classification, evaluation suite/version and activation/rollback events. `TeachingProposal`: current/proposed versions, intended change, source provenance, affected tasks and evaluation plan. `RegressionRun`: selected examples, expected constraints, actual outputs/model receipts, evaluation findings and reviewer decision. `RuleUse`: task/answer/artifact, rule version, retrieved source set and reason. None contain credential grants.

Prototype behavior: create a scoped rule, preview it, review two deterministic example checkboxes, activate a version, correct it, restore prior behavior as a new version, forget it and switch contexts. The UI explicitly labels these as human review fixtures, not actual model regression evaluation. The saved rule is inspectable; it does not retrain a provider or make the scripted chat adaptive.

## Delivery order and acceptance

Include primary model controls, permission visibility, Assistant/Collaboration enforcement contracts and basic Teach inspect/version workflow in the initial vertical slice. Production Proactive and specialist execution follow server policy, budget, receipt and cancellation gates. Advanced Auto routing and actual model regression evaluation follow verified rosters and permitted provider access.

Acceptance: unavailable model never silently substitutes; agent-default change does not change an existing task; running override checkpoints subsequent work; actual-model receipt remains unknown until supplied; mode downgrade fences all later effects including children; same permitted work produces the same boundaries in every persona; a taught email instruction cannot grant a tool; cross-context teaching/retrieval is denied; rollback changes behavior version without restoring revoked authority.
