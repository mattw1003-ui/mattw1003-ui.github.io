# Revision 2 validation — synthetic browser prototype

The original design validation record dated 25 October 2026 reports **129 passing checks**, no browser runtime errors and no external network requests during the exercised flows. These are historical results; this public repackaging did not execute app scripts or rerun the browser suite. The independently recorded selected-palette calculation passes ten static foreground/background pairs at 4.5:1 or greater. This is not a complete accessibility audit.

Viewports exercised: desktop 1440 × 1100; tablet 834 × 1112; phone 390 × 844; small phone 320 × 740. Root layout overflow checks cover all five navigation destinations, graph/list, Agent Studio and Team. Screenshots are browser renders, not iPhone/iPad Simulator captures. Selected original screenshots are retained in ../screenshots/; they do not establish native-device behavior.

## Exercised interactions

- Home addresses Matthew; active preference edits update its memory preview; forgotten preference text disappears.
- Work/Personal fixtures, preferences, profile names, avatars, memories and teams remain separate in UI/storage behavior. Context switching stops the voice simulation. This does not establish secure backend isolation.
- Graph node selection updates its inspector; graph/list/search expose active records; memory correction records supersession; forget persists; export includes only current-context active memories; selected preference transfer requires consent and professional record transfer is blocked.
- Persisted task/field drafts survive navigation/reload. Stop speaking preserves a running task, steering changes its artifact, cancellation waits for acknowledgment and blocks action consent. Explicit simulated effect receipt differs from authorization.
- Missing expected evidence is distinguished from complete transcription. Limitation carries to report; missing signer blocks issuance; evidence edits invalidate report review and flag the linked task draft.
- Contractor response completeness differs from acceptance; assignment packet changes reopen acceptance; potential scope exception remains a candidate. Driving briefing mode defers action authorization. Outdoor mode is selectable.
- Agent Studio name/role/tone persist; abstract/local-image avatars work; inert generated-avatar sample requires consent. Personal profile is unaffected by Work edits.
- Specialist delegation requires scoped consent; concurrency/shared budget checks block additional reservations; result needs parent review; conflict held for source review; reuse requires fresh consent; parent cancellation propagates and prevents new children. Actual provider usage remains explicitly unreported; sample usage is simulated.
- Keyboard focus is available; visible primary buttons meet the checked 44 CSS-pixel height. Native points, VoiceOver, Dynamic Type and real outdoor ergonomics are not covered.

## Model, permission and Teach checks

The expanded suite also verifies primary model control visibility; exact model default versus pinned task override; Auto allowlist consent; running-model checkpoint review; unreported actual-model receipts; separate Personal model defaults; Assistant side-effect blocking; explicit Proactive standing consent; mode downgrade revocation and receipt preservation; Teach activation only after reviewed examples, versioned correction/rollback, persistence, forgetting and context separation. Teach layouts also fit all four viewport widths. The teaching examples are human review fixtures, not model behavior evaluations.

## Implemented versus conceptual

| Working browser demonstration | Proposed, unimplemented or untested |
|---|---|
| Five destinations, responsive layouts, context labels, outdoor mode | Native SwiftUI navigation, iPad multitasking, Dynamic Type/VoiceOver |
| localStorage drafts and checkpoints | Transactional device persistence, encrypted backup/restore, sync/outbox concurrency |
| Scripted conversation and task artifact interactions | Real models, Chief execution, verified provider usage, backend timeouts |
| Inert voice/live/transcript/briefing controls | Microphone, speech output, duplex media, audio interruption/background/device tests |
| Context-filtered synthetic graph/list and memory lifecycle | Server authorization, index/cache deletion, source sync, secure export/transfer |
| Primary model selection, permission mode demonstrations and Teach versions | Actual model routing/usage, server permission enforcement, real regression evaluation or training |
| Names, avatars, local image selection, consented prebuilt sample | Paid image generation, production media validation/metadata handling |
| Simulated child tasks and shared-budget/concurrency gates | Real capabilities, durable reservation settlement, worker leases, cancellation race handling |
| Draft/review/action status demonstrations | Signed engineering issuance, immutable PDF service, real email/calendar/Quo receipts |

## Evidence provenance and scope

A portfolio review and selected sanitized Hub source/icon informed the original design. Original app archives were not directly inspected, and current deployment parity remains unknown. The SML icon is retained unmodified from that sanitized source. Prototype records and field illustrations are synthetic; there is no reusable signature artwork or real client evidence. See ../PROVENANCE-AND-LIMITATIONS.md.

No native Apple runtime, TestFlight parity, production source/backend, RLS, identity grant, provider access, billing, device service, security penetration or real restore tests were performed. No test result should be interpreted as production readiness.
