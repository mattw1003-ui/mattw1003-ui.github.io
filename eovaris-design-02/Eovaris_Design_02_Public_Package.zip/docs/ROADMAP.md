# Implementation order and decision gates

The 53-item BACKLOG.csv carries owner roles, dependencies and acceptance evidence. This is a design backlog, not an authorization to implement connected features.

## Gate 0 — verify and preserve

B01–B04, B10, V202, V211, V213–V214. Inventory the current Eovaris build/backend and compatible identity/credential references; current PlanPilot Microsoft/Quo capabilities; exact source-to-UUID mappings; Hub/Supabase domain ownership; complete evidence restore; context authorization; provider retention and budget policy. Use supported read-only inspection. Preserve working app/provider routes. No migration or new access grants until the domain and identity decisions are approved.

Exit: one signed-off writer per domain, no unresolved auto-merge candidates, restore proof, compatible-upgrade evidence and a precisely scoped list of any unavoidable reauthorization. Archive findings do not prove deployed configuration.

## Initial vertical slice — one visit, one task, one report

B05–B16, B18–B21, G01–G06, V201/V203–V206/V212/V216, scoped to one human-reviewed inspection scenario. Matthew opens Today; reviews the accepted visit packet; captures original observations; reconciles missing evidence before leaving; preserves a limitation; prepares a contractor request and report draft; reviews the two distinct authority paths; leaves and resumes the same task artifact. Exact job suffixes persist throughout. A basic Agent Studio personalizes names/avatars without changing policy. Small memory graph/list and source explanations support the same work.

Work/Personal shell and storage isolation belong in the foundation. Personal live connector execution does not ship until isolation and separate grants pass. Keep advanced live voice and autonomous specialist execution out of the critical path. Typed collaboration and existing authorized reads/drafts provide a usable first release.

Exit: offline/force-quit/restore tests recover original evidence; partial coverage never claims completeness; changed content invalidates review/consent; missing signer blocks issue; unknown external outcomes do not replay; correction invalidates dependent drafts; appointment confirmation, assignment acceptance and readiness remain distinct.

## Next — controlled execution, voice capture and specialist teams

Verified Work connector reuse and separately authorized Personal integrations; native push-to-talk and transcript recovery; durable Chief runs and receipts; app-memory deletion/index enforcement; delegated human handoff permissions; bounded specialist child tasks with concurrency/depth/shared spend/time and parent review. Reusable profiles carry role/templates only. Avatar upload needs production image validation/metadata policy. Personal planning ships only with proven context boundaries.

Exit: cancellation races and unknown outcomes reconcile; no child can exceed authority or reopen a canceled parent; actual usage remains null until received; cross-context and revoked-access tests cover cache, graph, export, notification and deep links; native audio interruption/background tests pass.

## Later — selective extensions

Live duplex voice and permitted custom voices; generated avatars with quote/consent/receipts; scalable relationship graph; optional Perplexity research; one human-approved requirements-to-evidence matrix pilot; sample-to-lab/result review where the actual testing workflow warrants it; richer specialist DepthMeasure/TraceRivet evidence handoffs. Driving integrations remain subject to official capability and device review.

No blanket AI compliance status, unbounded recursive delegation, automatic billing, inferred professional authority or automatic Work/Personal sharing is proposed.

## Decisions Matthew and responsible owners still need

1. Confirm Eovaris naming/upgrade path and the exact current release/backend identities.
2. Assign one operational writer per domain across Hub and PlanPilot, with named cutover/rollback owners.
3. Establish Work/Personal retention, export/transfer and provider data-handling policy, including whether any managed session service is acceptable.
4. Approve actual connector capabilities and only the new scopes proven necessary; verify existing grants first.
5. Choose the first inspection workflow and professional reviewer/signer rules; approve the expected-evidence checklist.
6. Choose default persona/voice, task and voice budgets, specialist concurrency/time limits and autonomy. Prototype dollar figures are illustrative, not provider quotes.

These are implementation gates; they do not prevent reviewing the local design now.

## Added model and trainability scope

V219–V221 add primary exact-model choice, Assistant/Collaboration/Proactive policy and Teach. Include visible model/permission controls and reviewed teaching versions in the initial slice. Real Proactive scheduling/execution waits for standing-grant enforcement, policy-revision checks, budget/receipt reconciliation and safe downgrade behavior. Actual learned-behavior regression evaluations require separately authorized provider access; this prototype uses labeled human-review fixtures only.
