# v2 screen plan and interaction specification

The original five-destination structure remains, with Assistant renamed Collaborate. All screens are context-scoped. Synthetic prototype coverage is listed separately from implementation acceptance.

| Screen | Matthew’s primary use | Detail and boundary |
|---|---|---|
| Today / Work | Know the next decision before leaving for a visit | Sourced brief, next visit, priority decisions, resumable artifact; one queue |
| Today / Personal | Resume a personal plan with a clear identity boundary | Distinct accent, Google identity label, personal memory/task count; no work snippets |
| Context switch | Choose which agent and authorized systems should handle the work | Unmistakable account/context labels; stop media, save scoped transcript, clear transient retrieval; no automatic item move |
| Projects | Find exact job and its plans/evidence/report | Same-name parent and inspection IDs remain distinct; one canonical registry |
| Pre-visit packet | Confirm scope and accepted coverage | Appointment confirmed, inspector accepted and site readiness reported separately; versioned packet |
| Capture | Dictate or type once, connect original evidence | Bound visit, original/derived lineage, links to finding/open item/request; optional specialist handoff |
| Before leaving | Resolve accessible evidence gaps or preserve limitations | Human-approved expected-evidence checklist; transcript coverage is a separate measure; departure never blocked for safety |
| Contractor package | Ask once, track what was answered | Original request and fields; received vs complete enough for review vs accepted; source-linked clarification |
| Team handoff | Verify acceptance and eventual evidence-backed completion | Assignee readback and packet version; a changed packet requires acknowledgment; actual multi-user permissions are gated |
| Report review | Compare frozen text, limitations and sources | Version-bound professional review; fail-closed issue; no reusable signature art |
| Collaborate / Conversation | Discuss, steer and create durable artifacts | Source chips, scoped draft composer, voice entry and linked task card |
| Collaborate / Tasks | Return to interrupted work and finish it | Stable task/operation, saved revision/checkpoint, pending dependencies, bounded plan and result receipts |
| Action review | Review exact external effect | Context/account/recipient/payload/attachments/expiry; separate consent and receipt; driving/cancellation gates |
| Collaborate / Memory | Inspect what is remembered and why | Source/time/confidence basis/applicability/supersession; edit, forget, current-context export and selected-item transfer |
| Graph / List | Follow useful relationships | Permission-filtered nodes and typed edges; search/type filter/zoom/focus; synchronized accessible list; no decorative galaxy |
| Voice / Live | Speak, interrupt output, steer or cancel distinctly | Explicit simulated/real recording indicator; transcript; Stop speaking / Change request / Cancel task; media and backend task status separate |
| Driving briefing | Hear a selected packet without visual review | Choose while stationary; concise orientation and pause/stop; approvals deferred; actual automotive integration proposed only |
| Preferences | Set collaboration style and allowed autonomy | Voice/style/length choices, Assistant/Collaboration/Proactive, per-context cap; no override of professional authority |
| Activity | Verify what happened | Context-qualified save/decision/cancellation/receipt events; missing receipt never becomes clock-based success |

Phone: a focused page/sheet, stable bottom tabs and source details on demand. Tablet: sidebar plus artifact and inspector, with a graph/list alternative. Outdoor mode increases borders/contrast and removes soft styling. Native Dynamic Type, VoiceOver, interruption and background audio are untested requirements.

## Agent personalization extension

Agent Studio is a secondary Collaborate destination: name, creative avatar, role, tone, permitted provider/model route, context, memory/tools and delegation/budget limits. Team is a fourth Collaborate mode beside Conversation, Tasks and Memory, not a new primary tab. Each specialist card exposes parent ownership, purpose, status, output, provenance and usage. Generation controls show cost/consent boundaries and remain inert here. The account/context label always survives persona customization.

## Model and Teach extension

Collaborate exposes Model and Permission beside its four secondary modes. Agent Studio holds the default model; a task holds its own selection/checkpoint and actual-model receipt. Model selection exposes compatibility, expected/unquoted cost and supported parameter controls; optional Auto needs explicit allowed models. Permission review shows Assistant, Collaboration and Proactive with named standing scope. Teach opens a focused proposal/example-review/version screen with source, owner, applicability, rollback and forgetting. No additional primary tab.
