# Eovaris evolved — Matthew's work and personal companion

Design revision 2 · 25 October 2026 · Synthetic prototype only

**Reuse-first direction:** evolve Eovaris as the likely product identity and existing app/backend foundation. Matthew reports OpenAI and Claude keys already linked, with PlanPilot Microsoft sign-in and Quo connections working. Treat those as current user-reported live state, not disproven by older archives. Preserve working provider routes and compatible connection references while verifying the actual build/backend before implementation. See REUSE-MIGRATION.md.

This revision extends the original PlanPilot + FieldScribe + Eovaris consolidation around Matthew's day as Director of Special Inspections & Testing. It adopts the conversational continuity and task-oriented interaction he values in AXIS; it does not claim AXIS feature parity, a working identity integration or verified voice/provider capability. The design was informed by a portfolio review and selected sanitized Hub source/icon. Original app archives were not directly inspected, and current production parity is unknown. See ../PROVENANCE-AND-LIMITATIONS.md.

## Product promise

Matthew can start a conversation, leave it, and return to the same task, evidence, drafts, decisions and execution receipts. He should not need to remember which app or chat contains the latest report. The app knows which context is active, explains why it remembers something, asks at real authority boundaries and preserves work when a call, drive or site interruption takes him away.

The home screen should be about Matthew's next decision, not a generic inspector's activity feed. It gives a short sourced morning brief, one primary next action, a resumable task and the few exceptions requiring his attention. All other detail is one deliberate step away.

## Experience principles

1. **Conversation produces durable work.** A useful assistant response can become a persistent task artifact: visit packet, request/response package, report draft, calendar proposal, decision record or scope exception. A conversation points to its artifact ID and revision; it does not become another document store.
2. **One context at a time.** SML Work and Personal have unmistakable labels, identity accounts, accents and service boundaries. Context is not inferred from what Matthew types. Ambiguous requests ask which context should handle them before retrieval or execution.
3. **Authority is visible at the decision.** Engineering review, signing, operational action consent, commercial review and memory consent remain distinct. A general autonomy preference cannot override them.
4. **Helpful memory can be inspected.** Persistent app-owned memory has a source, date, scope, confidence basis, applicability and supersession. It is not magic imported from ChatGPT or Claude product memories.
5. **Capture once, carry the evidence forward.** A field observation links to a report finding, open item, contractor request and scope exception without rewriting or duplicating its original evidence.
6. **Progress must be real.** Show the last durable checkpoint, pending dependency and verified result. Streaming speech and animated progress are not proof that backend work happened.
7. **Useful graph, quiet interface.** Relationships explain why something matters; the graph is searchable, permission-filtered and optional. No decorative galaxy, character or competing dashboard.

## Information architecture

Keep five primary destinations: **Today · Projects · Capture · Collaborate · Activity**. Collaborate is the former Assistant destination, emphasizing conversation and durable task work. Its secondary modes are Conversation, Tasks, Memory and Team. Agent Studio opens from Collaborate or Team and does not add a sixth primary destination. Memory is also reachable from “Why this?” beside a recommendation and a single secondary sidebar shortcut on iPad; it does not require a sixth phone tab.

Work Projects use the shared SML registry and exact job IDs. Personal Projects use a separate personal workspace registry; they never show SML projects by default. Capture can store work evidence or a personal note under the selected context, with different policies. Changing the context cannot move an active work recording into personal storage.

On iPhone, tabs remain stable and a task opens as a focused page or sheet. On iPad, the sidebar, central conversation/work artifact and contextual inspector can coexist. The graph opens beside its selected record; a plan can sit beside a finding. Layout adapts, but task identity and approval semantics do not change.

The toolbar always names **SML Work — Microsoft / smleng.com** or **Personal — Google** and shows actual connection status when implemented. The prototype labels both as proposed/unconnected. Do not invent Matthew's email address. Use verified Microsoft tenant/user IDs and Google subject IDs. Selecting a domain alone does not authenticate an identity or establish company authorization; login also does not grant mail/calendar connector scopes.

## First screen: a clear start for Matthew

The Work home opens with “Good morning, Matthew” and a brief such as “One decision before your next visit.” A visible source/freshness link explains the basis. The primary action is contextually selected from explicit facts: review the current packet, resolve a missing assignment acceptance or resume the last draft. It does not automatically rearrange the screen based on inferred mood or hidden urgency.

Below it are three compact rows: **Next** (time/site/scope), **Needs you** (professional review and operational actions with distinct badges), and **Continue** (artifact title, checkpoint and next decision). The complete shared queue remains available. Matthew can pin a task and override the suggested next action. Source errors create a visible freshness gap, not a reassuring zero.

A persistent conversation entry offers typing or push-to-talk. It is not an always-listening microphone. “Brief me” opens an audio-first briefing mode; “Why this?” opens the exact evidence or memory used. The interface exposes source and authority details progressively rather than filling home with technical metadata.

Personal home uses a different accent and label, separate tasks and a calm agenda. It can support personal planning against authorized personal sources once connected. It cannot search SML records simply because Matthew owns both accounts.

## Matthew-specific journeys

| Moment | Journey | Persistent outcome and boundary |
|---|---|---|
| Morning triage | Matthew opens Work, hears/reads a concise brief, sees source freshness, reviews one decision and pins the next visit | Same Today queue; dismissal does not close an underlying deficiency or approve an action |
| Driving / pre-visit briefing | Before moving, he selects the visit and starts a brief. While driving, use audio-only orientation with simple pause/stop or defer; no visual review or approval prompt | A paused briefing retains its position. Messages, approvals and detailed edits wait until he is stationary; no CarPlay or motion-detection capability is claimed |
| On-site capture | Open the bound visit, verify scope/plan revision, dictate observations and attach original evidence with element/location | Durable local originals and a saved transcript; observations keep observed/reported/inferred distinctions |
| Before leaving | Check the human-approved expected-evidence list against what was actually captured; add accessible evidence or record a limitation and follow-up | A visit can end with unresolved items. Transcript completeness is not inspection completeness. The app never prevents leaving an unsafe site |
| Contractor coordination | Convert the original request into structured job/scope/stage/time/access fields. Draft one clarification. Review response as received, complete enough for review and separately accepted | Request/response package survives chat; no automatic reply or technical closure |
| Report review | Open the frozen revision beside its sources, review limitations and nonconformance, request changes or record professional review | Changes invalidate review for changed content. Issue remains separate, fail-closed and bound to immutable bytes |
| Calendar confirmation | Review the exact event account, site/time/zone/attendees and source messages; distinguish contractor confirmation, inspector acceptance and reported readiness | Authorize exact payload; await verified receipt and readback. Calendar presence alone is not accepted coverage |
| Team handoff | Assign a versioned packet. The inspector accepts/clarifies/declines and reads back scope/limits. Review an evidence-backed handback | Requires live delegated authorization before rollout. “Delivered,” “read,” “accepted” and “completed/accepted handback” remain different |
| Scope exception | Record an extra requested location/test, access delay or return visit while facts are fresh; link requestor, scope, actual work and attested time or null | Commercial review candidate only; no inferred billable hours or automatic change order |
| Conditional decision memory | Record written direction with actual authority, affected revision/location, conditions and required closure evidence; surface unfinished conditions next visit | A historical EOR decision is not a universal rule; material changes trigger applicability review |
| Personal planning | Switch explicitly to Personal, use authorized Google/Gmail sources, prepare a personal plan or calendar draft, review the destination before action | Separate personal state, source graph, credentials, budgets and receipts; no work retrieval |
| Interrupted task | Reopen a conversation or task from Today. See last confirmed checkpoint, saved artifact revision, pending approval and unknown outcomes | Resume by task/operation ID, not by replaying the last prompt. Reconcile unknown effects before retry |
| Why the agent remembers | Tap a memory used in the answer; inspect source, date, scope, confidence basis, applicability and supersession; correct, forget or export it | Editing supersedes the old memory for retrieval. Forgetting assistant memory does not silently delete required source/audit evidence |

## Work and personal agent architecture

There is one application and one coherent interaction model with two isolated execution contexts. **Work continues to use the existing Ops Hub Chief.** A personal context should use the same reviewed orchestration contract only if the existing backend is extended and verified for strict context isolation; otherwise personal execution remains disabled. Do not create an independent mobile agent brain or imply that the existing owner-scoped Hub already provides multi-context security.

The work context should reuse the user-reported PlanPilot Microsoft sign-in through verified compatible adapters and authorization, rather than assume a new account setup. The intended identity is authorized for the SML tenant and smleng.com systems. The personal account is Matthew's chosen Google identity and separately authorized personal systems. Authentication, connector permissions and the right to perform a specific action are distinct checks. Account linking is not automatic because names match. Identity/voice integration details require current official-capability and account-access verification before implementation.

| Boundary | Required separation |
|---|---|
| Credentials | Distinct identity sessions, token/keychain namespaces, connector grants and revocation; no fallback to the other account |
| Local/backend data | Context-keyed stores, files, outbox, artifacts, search indexes, retention/encryption policy and backup manifests |
| Retrieval and graph | Server permission filter before retrieval, graph traversal, counts, snippets and search suggestions; no hidden unauthorized node labels or edges |
| Memory and prompts | Context-scoped memory IDs and retrieval manifests; model sessions/prompts contain only authorized context; no provider-wide shared conversation memory |
| Tool execution | Context-specific connector/account allowlist, actor capabilities, consent, idempotency, budget and receipt validation |
| Notifications | Context-qualified event IDs and routes; lock-screen content redacted by policy. Tapping a work notification while Personal is active requires an explicit switch and reauthorization |
| Audit/exports | Work audit policy and personal history policy remain separate. Export selection never defaults to both contexts |
| Analytics/usage | Separate usage/quotas and content handling; avoid raw sensitive prompt content in general analytics |

Context switching ends or pauses the active live voice session, commits the current local transcript, clears transient retrieval/view state and loads the other context's services. Backend work already accepted in Work remains Work work; the UI offers a scoped task receipt when returning. A switch does not silently cancel, migrate or duplicate a task. The app reports whether cancellation was accepted if requested.

### Explicit selected-item transfer

Cross-context transfer is a separate deliberate workflow: select one permitted item, choose destination, inspect the exact copied fields and redactions, confirm, then create a new destination record with a transfer event. Default is no transfer. Include neither unselected attachments nor source-neighbor graph nodes. Destination retrieval cannot follow a source pointer back into the other context.

Policies may prohibit professional/client evidence or company records leaving Work. The prototype permits an innocuous synthetic preference and blocks transfer of a professional decision. A future work-calendar availability transfer could expose only a busy interval, if authorized, without client/site/title details. A transfer does not merge memories or synchronize edits automatically.

## Persistent app-owned memory

Persistence belongs to the application/backend, not a model vendor's product UI. Do not claim ChatGPT/Claude product memories automatically arrive through APIs. Changing providers should preserve the app-owned record model and permissions without copying vendor-internal memory.

Distinguish four categories: **preferences** (how Matthew wants collaboration), **project decisions** (source-backed authority and conditions), **task continuity** (checkpoints and artifact pointers), and **derived suggestions** (unconfirmed inferences with limited lifetime). Authoritative project records remain in their existing source/Obsidian/transactional systems; memory is a traceable projection or explicitly saved preference, not a competing facts database.

Memory fields: stable ID, tenant/context, kind, text, source ID/version/locator, source classification, source event time, recorded/updated time, author/reviewer, confidence basis, applicability including project and validity interval, sensitivity, status, supersedes/superseded-by, expiry/review date, retrieval policy and affected tasks. Do not present invented numeric confidence as source verification. An explicit preference can say “stated by Matthew”; a derived suggestion says “inferred; not confirmed.”

Controls:

- **Inspect / Why remembered:** show the source excerpt and timestamp, when it was last used, where it applies and the answer/task that used it. Unknown source stays unknown.
- **Edit:** create a correction/superseding version. Updating an assistant summary cannot edit a source EOR decision; route source corrections to the authorized record workflow.
- **Forget:** stop use in retrieval/personalization, tombstone indexes and caches, record deletion completion status, and suppress automatic re-creation from the same derivation unless Matthew opts back in. Show which source/audit records remain under policy. Do not claim remote/provider/backups erasure without verified scope and receipts.
- **Export:** selected/current-context readable JSON or Markdown with provenance and restrictions; exclude credentials and unauthorized source contents. Proposed production export requires retention/privacy policy checks.
- **Review inbox:** memory suggestions appear within the same task/queue experience; no separate competing memory inbox. Sensitive or consequential inference requires confirmation before persistence.

### Relationship explorer

The graph is an optional permission-filtered view over memories and their sources, projects, tasks, decisions and reports. Typed edges include derived from, applies to, supersedes, supports and waiting on. Select a node to inspect it; select an edge to explain the relationship and its basis. Search, node-type filters, zoom, focus-on-neighbors and a synchronized list provide utility. A keyboard/VoiceOver-accessible list exposes the same records and actions; the graph is never the only way to find or manage memory.

The prototype shows a small synthetic context-local graph with selectable nodes, search, list mode and zoom. It does not implement production graph storage, server authorization, large-graph layout, pan gestures or source-system synchronization. No hidden work nodes are rendered in Personal.

## Voice, live collaboration and continuity

### Proposed modes

1. **Push-to-talk:** explicit press/start and stop; visible app recording indicator, elapsed time and transcript. Suitable for short field notes and task steering. Permission denied or interrupted recording preserves completed local segments.
2. **Live conversation:** explicitly start a session; show listening, transcribing, thinking and speaking as separate states. Interrupt spoken output, steer the objective or pause. Stopping speech does not prove backend execution has stopped; task cancellation is a separate command/receipt. Provide three distinct controls: Stop speaking, Change request and Cancel task. A durable cancellation state must fence later effects; completed effects remain subject to reconciliation.
3. **Hands-free field capture:** opt-in session with obvious active indicator, an easy stop control, clear consent/retention expectations and original audio policy. Do not silently include nearby conversations or keep recording after a context switch.
4. **Briefing mode:** concise audio-first summary, selected while stationary; minimize interaction while driving. Surface unresolved issues verbally and save reviewable actions for later. Voice is not an alternative path around engineering review or high-impact action consent.

Customization covers approved provider voice choices once verified, speaking rate where supported, concise/thorough response length, calm/direct/warm style, pronunciation preferences and the level of interruption feedback. Persona is a communication preference, not a change to authority or truthfulness. Prompt-generated voice design is a documented option for GPT-Live, subject to account setup; recorded-person cloning has separate eligibility/consent requirements. Do not promise automatic AXIS voice cloning. The prototype offers style/length settings but no actual voice output or voice creation. See INTEGRATION-NOTES.md for current official sources and policy gates.

Voice streaming is an ephemeral media connection. Durable tasks run through Chief's persisted backend state with job/operation IDs, leases, checkpoints, budget reservations and result receipts. Ending the stream or closing the app does not establish task failure or success. On return, fetch the known operation and resume the artifact. Unknown connector/provider outcomes reconcile before replay.

**iOS boundary:** do not promise unlimited always-on microphone access or continuous execution while locked/backgrounded. Availability depends on the approved audio-session/background configuration, permissions, system interruptions and tested device/OS behavior. The app must show recording state, handle suspension/interruption and persist completed evidence. Background task scheduling and push notifications do not keep a live microphone or arbitrary agent loop alive. Exact entitlements, supported SDK modes and transport/provider capabilities are proposed pending official verification and native tests. The prototype requests no microphone, camera, identity or notification permissions.

## Autonomy and cost

Provide three context-specific modes: **Assistant** reads permitted sources and writes drafts/internal artifacts without external side effects; **Collaboration** executes only after live approval of an exact action or clearly bounded batch; **Proactive** initiates/completes work within explicitly enabled standing scope. Label Proactive **Full access to selected scope**. Account/tool/action allowlists, effect/spend/time limits and expiry remain enforceable server policy. Professional sign-off, high-impact/irreversible actions and credential/security gates remain separate. Downgrades revoke queued authority and require an in-flight recheck before the next side effect; completed/uncertain effects need receipts and reconciliation. Children cannot exceed parent policy.

Model choice is a primary Collaborate control, with per-agent defaults and per-task overrides. Show exact provider/model, compatible modalities, supported reasoning/speed parameters, estimate/cap and actual model receipt. No silent fallback; Auto requires an explicit permitted roster and budget. Running changes checkpoint subsequent work. **Teach** exposes reviewed preferences, examples, templates, corrections and reusable skills with source/owner/scope, regression review, versioning, correction/forgetting and rollback. No silent model-weight training or permission learning. See MODEL-PERMISSIONS-TEACH.md for contracts and tested-versus-proposed details.

Task plan review shows outcome, sources, permitted operations, exclusions, account/context, cost cap and expiry. The server must reserve budget durably, enforce concurrent-worker limits, retain uncertain reservations, reconcile usage and report missing cost as unreported. Separate work/personal budgets. Voice-session usage and backend task usage are separately visible; a quiet microphone does not mean a running task stopped incurring cost. Effective model IDs remain unverified until runtime receipts establish them.

## Visual direction and accessibility

Modern business styling comes from hierarchy and responsive continuity: a graphite shell, crisp content, a restrained crimson accent in Work, distinct indigo in Personal, compact source chips, clear progress and well-spaced task artifacts. Use a system font, meaningful icons and modest transitions. No robot imagery or decorative graph motion. Use motion only to preserve orientation; respect Reduce Motion.

Outdoor mode removes soft shadows/translucency, maximizes contrast and gives field controls stronger boundaries. Maintain at least 44-point touch targets in native implementation, a 48-point primary action target, Dynamic Type, VoiceOver labels and keyboard navigation. The browser prototype uses CSS-pixel targets and cannot validate native point sizing or assistive technology. Graph/list parity, transcripts and visible recording state are mandatory, not optional accessibility extras.

## MVP and later phases

**MVP design slice:** unmistakable context shell with execution disabled where backend isolation is unverified; Work Today and persistent task artifact; typed collaboration; source-linked answer; basic inspect/edit/forget/export memory; searchable graph/list for a small scoped set; before-leaving checklist; structured request/response; versioned assignment example; scope exception; conditional decision; unchanged professional/action approval boundaries. Native work pilot should prioritize durability, recovery, correct identity and permission enforcement before adding personal connector execution.

**Next:** verified Microsoft and Google account integrations, delegated team permissions, production memory lifecycle/index deletion, push-to-talk on tested devices, bounded Chief execution/receipt reconciliation and controlled personal planning. Each can ship only after its specific integration/security gates pass.

**Later:** verified live voice/interrupt behavior, background/lock-screen audio tests, driving integrations if supported, scalable graph and typed edge inspection, scoped requirement-to-evidence matrix for one human-approved inspection type, advanced sample/lab lifecycle and reviewed cross-project precedent. No blanket AI-generated compliance matrix.

## Acceptance criteria

- Work and Personal differ visibly; switching stops live media and cannot carry a prompt, source snippet, graph node, task artifact, notification detail or connector grant across contexts.
- A selected-item transfer previews every field, respects policy, logs the event and creates only the selected destination item; no implicit edges to protected source neighbors.
- Memory has source/time/applicability/confidence basis; correction supersedes rather than rewrites authority; forgetting removes retrieval and prevents silent re-creation, with retention limits disclosed.
- Returning after interruption resolves the same task/operation and artifact revision; no duplicate execution or false receipt from elapsed time.
- Voice indicators match actual recording in native tests; context switch/interruption handles media explicitly; user can interrupt speech without an unsupported claim that work was canceled.
- Before-leaving review finds an uncaptured expected observation even when all transcript segments are processed; an unresolved condition stays unresolved.
- Contractor response receipt, completeness and acceptance are separate; assignment acceptance and completion proof are separate from appointment confirmation.
- Professional issue remains fail-closed; action authorization remains distinct from receipt; budget controls persist across restart and concurrent work.

## Current evidence limits

No direct app archive or app-asset inspection; no current production Hub/Supabase ownership reconciliation; no verified model/voice/identity integration; no native Apple runtime test. All prototype data and state changes are synthetic local demonstrations. Prior v1 test results do not cover this revision; v2 validation records its own exercised flows. No credentials, OAuth grants, billing changes, external actions, publication or failed-transfer retries are part of this design.

## Integration selection remains gated

A separate voice layer can delegate to the existing Chief backend. Do not send audio directly to gpt-6.1-sol; its documented modalities are text and image, with audio unsupported. Agents API is a possible durable-session building block, not a selected replacement for Chief: its current beta, US-only residency and lack of Zero Data Retention require policy review before sensitive SML evidence. Default to separately assessed API billing; eligible ChatGPT plan usage is not universally excluded, but its feature/access limits must be verified for the actual hosted app. No configuration or provisioning is authorized here.

## Optional research provider

Perplexity is an optional provider-adapter proposal pending official API and account verification by the parent. Keep existing OpenAI and Claude providers operational and keep Chief as orchestrator. Research answers carry cited external sources and remain separate from project records and engineering determinations. No paid call, new key, provider setup or credential migration is authorized. Research tool scope, source disclosure and budget must be reviewed before any live use.

## Personalizable leads and specialist teams

Agent Studio lets Matthew independently name and style the Work and Personal leads, use creative selectable/uploaded avatars and consider a separately consented generated-avatar flow. Security context remains explicit. Leads can delegate bounded internal AI tasks to ephemeral specialists or explicitly saved reusable profiles. Team view shows purpose, parent ownership, status, deliverable, actual usage availability and provenance. Parent reviews and integrates results; children inherit only selected context and a narrower capability set. Concurrency, depth, total time/cost, cancellation propagation and conflict review are mandatory. Persona text cannot change policy. See AGENT-STUDIO.md for contracts and prototype coverage.
