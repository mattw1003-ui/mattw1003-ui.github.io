# v2 contract extensions — design only

These extend the v1 common record and operation envelopes, preserving exact job strings, app UUID mapping, immutable original evidence, frozen issued artifacts and separate professional/action approvals. They are not implemented production endpoints or a proposed second master store.

## Context and identity

`AgentContext`: context_id, kind(work/personal), owner_principal, identity_provider, verified_subject_id, verified_tenant_id where applicable, connector_principal_ids, policy_version, retention_policy_id, budget_policy_id, encryption_namespace and current_authorization_revision. A display email/domain is not an authorization key. Microsoft login does not grant Outlook scopes; Google login does not grant Gmail/calendar scopes.

Every conversation, message, task, artifact, memory, graph node/edge, notification, outbox command, consent, receipt and usage record carries context_id. The server derives it from a verified principal and rechecks access at execution time. Client context selectors are not security enforcement. Personal execution cannot use Work tokens if a personal connector is unavailable.

## Memory lifecycle

`MemoryRecord`: id, context_id, type(preference/decision_projection/task_continuity/derived_suggestion), text, source_refs with exact source versions, source_classification, source_event_at, created_at, updated_at, actor, reviewer, confidence_basis, applicability(project_ids, conditions, valid_from/to), sensitivity, version, status(proposed/active/superseded/forgotten/expired), supersedes_id, review_due_at, retention_policy_id and derivation_fingerprint.

`MemoryUse`: memory_id/version, task_or_answer_id, retrieval_policy_version, retrieval_at and reason. This supports “why remembered/used” without inventing a last-used claim. A source decision and its assistant projection are different records; editing the projection cannot change professional authority.

`MemoryForgetRequest`: selected IDs, requested scope, source_retention_explanation, deletion_operation_id and status. Tombstone the active retrieval view, vector indexes, caches and derived graph nodes. Suppress automatic re-derivation by fingerprint unless the user reverses that choice. Preserve only policy-required minimal audit; disclose source/legal-retention limits. Do not expose old text in active search, graph or prompts. Backups/provider copies require separately established deletion policy and receipts.

`MemoryExport`: one context, selected IDs or explicitly selected active set, schema version, source metadata permitted for export, sensitive-field redactions and manifest hash. Never include credentials or unselected contexts.

## Graph projection

`GraphNode`: id, context_id, underlying_entity_type/id/version, label, permission_scope, status, permitted_summary. `GraphEdge`: source_id, target_id, relation(derived_from/applies_to/supersedes/supports/resumes/waiting_on), evidence_basis, source_version, context_id and permission_scope.

Apply authorization before traversal, aggregation, search suggestions, count generation and serialization. Edges do not grant access. Do not reveal redacted node labels, hidden relationship counts or inaccessible source snippets. The list/search API exposes the same authorized records and actions as the graph. A production node selection reauthorizes the underlying record.

## Explicit cross-context transfer

`ContextTransfer`: id, source_context, destination_context, source_item_ids, selected_fields, redaction_manifest, source_policy_decision, preview_hash, actor_consent, created_destination_ids and audit_receipts in each context. Default deny. Recheck policy and preview hash on commit. Only copied, approved fields become destination data; an origin pointer must not allow cross-context retrieval. Edits are not auto-synchronized. Prohibited professional/client data remains in Work.

## Task continuity and cancellation

`TaskArtifact`: task_id, context_id, artifact_id/type, current_revision, content_hash, source_manifest, checkpoint, next_required_decision and related_approval_ids. Conversations reference the artifact; they do not duplicate its authoritative contents.

`RunAttempt`: task_id, attempt_id, context_id, operation_id, scope_manifest, policy_version, allowed_tools, budget_reservation, step/time caps, worker_lease, state, last_durable_checkpoint, steering_revision and receipts. A new attempt has a new operation identity; reconnecting to an uncertain attempt reuses its identity and reconciles its state.

`TaskSteering`: task_id, target_attempt, context_id, revised_objective, revision, source_user_event, received_at, applied_at or rejected_reason. Changed proposed action content invalidates the old payload consent. Steering a voice model is not proof that a worker applied the change.

`Cancellation`: task/attempt ID, requested_at, state(requested/acknowledged/reconciliation_required), fence_version, worker_ack, prevented_pending_effects and already_completed_receipt_ids. Executors check the current fence immediately before a side effect using a transactional claim/authorization check. Revoke pending execution claims where possible. An uncertain already-started effect stays under reconciliation; do not claim universal rollback.

## Voice session

`VoiceSession`: id, context_id, authorized_voice_profile, transport_session_id, media_state, explicit_capture_consent, microphone_indicator_state, started_at, interrupted_at, transcript_segment_ids and linked_task_ids. Store raw audio only under an explicit retention policy; preserve field originals when the capture workflow requires them.

`VoiceControl`: stop_output, steer_request and cancel_task are distinct commands. End-session closes media; it does not rewrite backend state. Context switch commits completed local transcript segments, ends media and clears ephemeral retrieval before the new scope loads. Native implementation must handle interruptions, lock/background changes, denied permissions and storage failure.

`UsageReceipt`: separate categories voice_session and task_run, measured provider data or null/unreported, currency and integer minor units, reservation/settlement IDs. Neither display silence nor speech interruption releases a task budget reservation.

## New field workflow records

- `ExpectedEvidenceItem`: human-approved visit-scope checklist entry, source citation, element/location, expected observation and completion/limitation evidence. This is a narrow first-slice checklist; formal requirement matrix remains later.
- `ResponsePackage`: request ID, original source messages/attachments, received status, completeness review and authorized acceptance as separate events.
- `AssignmentAcceptance`: exact assignee, packet version, accept/clarify/decline, readback/limits and proof-linked handback; delivery/read status is separate.
- `PotentialScopeException`: original scope reference, requested/authorized/performed facts, requestor source, work evidence, attested time or null and commercial review state.
- `ConditionalDecision`: actual source authority, affected job/revision/location, conditions, validity, supersession and closure evidence; precedence is explicit.

All use the existing Hub-facing owner and project-control contracts after operational ownership reconciliation. No actual backend mutations were performed.
