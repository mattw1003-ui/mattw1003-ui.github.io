# Architecture decision map — Eovaris evolved

Design only. The diagram names logical boundaries, not newly deployed services. Reuse the live Eovaris identity and compatible backend/credential references after verification. The existing Ops Hub Chief remains the work execution owner; personal execution is disabled until that orchestration contract supports verified isolation. No second independent orchestration brain is proposed.

```mermaid
flowchart TD
  UI[Native Eovaris app: Today / Projects / Capture / Collaborate / Activity]
  UI --> W[Verified SML Work context]
  UI --> P[Verified Personal context]
  W --> WL[Work local originals / drafts / outbox]
  P --> PL[Personal local state / outbox]
  W --> F[Existing Eovaris backend: versioned context and policy facade]
  P --> F
  F --> C[Existing Hub Chief: scoped task and child-run execution]
  F --> O[Obsidian knowledge adapter: source versions and locators]
  F --> R[Domain owner adapters: Hub or PlanPilot per approved register]
  C --> G[Context-bound capability broker: grants / consent / budget / cancel fence]
  G --> X[Authorized connector and provider adapters]
  X --> RC[Verified receipts and usage reconciliation]
  RC --> C
  F --> M[Context-separated app memory and permission-filtered graph projections]
  V[Proposed voice layer: explicit media session] --> F
```

Work and Personal use separate tokens/principals, storage and encryption namespaces, retrieval indexes, memory/graph records, notifications and audit policy. The shared diagram box does not mean shared authorization. The server derives scope from verified identity and rechecks it on every read and effect. A client toggle or prompt instruction is insufficient. Voice and model providers receive only permitted selected context. Specialist children receive a strict subset of the parent capability and source manifests.

| Domain | Proposed architectural disposition | Evidence / unresolved decision |
|---|---|---|
| Installed app identity | Evolve Eovaris; preserve compatible bundle/team/App ID prefix/keychain groups | Archived source notes describe device-only session storage; current entitlements/build must be verified |
| Provider secrets | Keep existing server ownership; client holds only permitted server session/reference | User reports OpenAI/Claude already linked; live configuration uninspected |
| Work execution and action queue | Existing Hub Chief and action/receipt contract | Sanitized snapshot supports contract design; current deployment must be inventoried |
| Project/document knowledge | Obsidian remains primary; retain source/version/locator | Graph and assistant memory are derived views, not replacement vaults |
| Jobs and aliases | One registry view; exact original string plus app UUID and source-system ID | Current authoritative writer must be reconciled between Hub and PlanPilot; no name-only merge |
| Plan control, draft reports, issuance | One writer for each domain; immutable issued bytes | Physical Hub versus PlanPilot ownership unresolved; no data-moving implementation selected |
| Original field evidence | Durable context-scoped device originals and selected authoritative object owner | Complete encrypted backup and clean-device restore are prerequisites |
| Work/Personal memory | App-owned records and projections; no imported vendor product memory | Storage, deletion/index policy and context enforcement require implementation |
| Perplexity | Optional bounded research adapter; no independent project queue, credentials or action authority | Search/cited research only after policy/access review; preserve existing providers |

**Ownership gate remains open.** Resolve current writer, proposed writer, role enforcement, record counts, evidence hashes, mapping conflicts and rollback owner for each domain before moving data. Until then, use read-only adapters and synthetic fixtures. This package intentionally does not invent a winner between current Hub and PlanPilot Supabase.

Native modules: context/session coordinator; project and plan control; capture/recovery; report lifecycle; conversation/task artifacts; memory explorer; Agent Studio; action review/activity; sync/outbox and policy-aware service adapters. SwiftUI provides adaptive shell and detail navigation. Transactional persistence and immutable files support recovery; browser localStorage is only a prototype device.

Shared envelopes require schema version, record UUID, context/principal, exact job/source mapping, base revision, operation/attempt IDs, source manifests, actor/time and audit links. Domain records add original evidence hashes, controlled plan decisions, frozen report versions, signer authority, payload-bound consent, durable budget reservations, cancellation fences and external receipts. Full contracts are in ../contracts/CONTRACTS.md plus CONTRACT-EXTENSIONS.md and AGENT-STUDIO.md.
