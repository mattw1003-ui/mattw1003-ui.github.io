# Eovaris Design 02 - public preview

This package contains a synthetic interactive browser prototype and design guidance for a proposed unified Eovaris experience combining PlanPilot, FieldScribe and Eovaris. It is not an installable iOS app or a production release. No accounts, microphones, models, paid services or live connectors are connected.

## Start here

1. Read Eovaris_Design_02_Public_Brief.pdf for the nine-page visual overview.
2. Read docs/PRODUCT-EXPERIENCE.md and docs/SCREEN-PLAN.md for the intended journeys.
3. Use docs/ARCHITECTURE-OVERVIEW.md, docs/REUSE-MIGRATION.md, contracts/ and docs/CONTRACT-EXTENSIONS.md to understand the proposed boundaries.
4. Review docs/ROADMAP.md and the 53-item docs/BACKLOG.csv before implementation.
5. Read PROVENANCE-AND-LIMITATIONS.md, docs/VALIDATION.md and RELEASE-NOTES.md.

## View the prototype locally

If Python is already installed, run this from the extracted package directory:

```sh
python -m http.server 8766 --bind 127.0.0.1 --directory prototype
```

Open http://127.0.0.1:8766/. This serves only the static prototype on loopback. Do not weaken browser policy to open local files. The prototype loads local assets and scripts; its content security policy blocks external network connections. Stop the server when finished.

Use synthetic data only. State is stored in separate Work and Personal browser localStorage namespaces. This demonstrates persistence and separation; it does not establish secure native storage or server authorization. The Reset control clears synthetic state. Selecting an avatar image stays in that browser; do not select private images or enter real client evidence, credentials or sensitive personal data.

## Try the design

- Today: distinguish the appointment, inspector acceptance and reported readiness; resume a saved task.
- Capture: edit a synthetic observation, review Before leaving, preserve a limitation and open the linked draft report. Missing signer keeps issuance disabled.
- Collaborate: use scripted conversation, inspect the task and distinguish Stop speaking, Change request and Cancel task. Authorization and a simulated receipt are separate steps.
- Memory: explore graph/list/search, inspect provenance, correct or forget a memory and export the active context. Explicit transfer permits one synthetic preference and blocks a professional record.
- Agent Studio and Team: adjust persona and a local avatar, select the no-charge sample, delegate a simulated specialist, review conflicts and cancel work. No real agent or provider runs.
- Model, Permission and Teach: inspect proposed model choices, Assistant/Collaboration/Proactive boundaries and reviewed rule versions. These controls do not alter model weights or real account permissions.
- Switch to Personal: observe separate labels, preferences, memory and teams. No Microsoft or Google account is connected.

The archived prototype and its local asset bytes are retained without behavior changes. The public release process inspected files without executing the contained app scripts. Historical browser results are described in docs/VALIDATION.md; native Apple, live backend, security, audio and production tests remain unperformed.
