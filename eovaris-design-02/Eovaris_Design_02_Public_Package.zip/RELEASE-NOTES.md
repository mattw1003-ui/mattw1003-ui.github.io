# Public release notes

This is a public-safe repackaging of Eovaris Design 02, not a byte-identical original archive. It retains the synthetic interactive prototype, design contracts, architecture, screen plan, 53-item backlog, instructions and selected screenshots.

Internal delivery logs, resource and workspace identifiers, source-audit extracts, build/capture scripts and unrelated operational handoff files are omitted. User-facing documents retain the substantive limitations and approval boundaries. The separately named public brief removes internal delivery details and source-review locators while preserving the nine-page design and its limitations.

No production app, live integration or installable native build is included. Original files are preserved separately. MANIFEST.json records exact sizes and SHA-256 hashes for every included file except the manifest itself.
